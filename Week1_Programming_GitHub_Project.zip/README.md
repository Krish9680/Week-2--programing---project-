# Week 1 Programming Sample Project: Student Grade Calculator

> **Important:** This is a sample beginner project, not a verified copy of your course's official Week 1 assignment. Check the course materials and adapt it if the instructor specifies a different task.

## Project overview
A simple Python program that accepts marks for three subjects, calculates the total and average, and assigns a grade.

## Concepts demonstrated
- Variables and numeric input
- Lists and basic validation
- Arithmetic operations
- `if` / `elif` / `else` conditional statements
- Output formatting and basic error handling

## Requirements
- Python 3

## Run the project
1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Run:

   ```bash
   python student_grade_calculator.py
   ```

## Example
Input marks: 85, 90, 80

```text
--- Result ---
Total Marks: 255.0 / 300
Average: 85.00%
Grade: B
```

## Files
- `student_grade_calculator.py` — runnable source code
- `Week1_Sample_Project_Report.pdf` — project report with algorithm, code, example output, and checklist
