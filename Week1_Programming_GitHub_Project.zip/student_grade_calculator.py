# Student Grade Calculator
# Beginner Python project demonstrating input, arithmetic, and conditionals.

def main():
    try:
        mark1 = float(input("Enter marks for Subject 1 (0-100): "))
        mark2 = float(input("Enter marks for Subject 2 (0-100): "))
        mark3 = float(input("Enter marks for Subject 3 (0-100): "))
    except ValueError:
        print("Invalid input. Please enter numeric marks.")
        return

    marks = [mark1, mark2, mark3]
    if any(mark < 0 or mark > 100 for mark in marks):
        print("Invalid marks. Each mark must be between 0 and 100.")
        return

    total = sum(marks)
    average = total / len(marks)

    if average >= 90:
        grade = "A"
    elif average >= 75:
        grade = "B"
    elif average >= 60:
        grade = "C"
    elif average >= 40:
        grade = "D"
    else:
        grade = "F"

    print("\n--- Result ---")
    print(f"Total Marks: {total:.1f} / 300")
    print(f"Average: {average:.2f}%")
    print(f"Grade: {grade}")


if __name__ == "__main__":
    main()
